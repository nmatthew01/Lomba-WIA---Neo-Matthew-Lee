# SambungWarga

**SambungWarga** is a community platform that brings emergency help, public service tracking and civic problem reporting into one app, so residents can see what happens after a problem is reported.
*SambungWarga adalah platform komunitas yang menyatukan bantuan darurat, pelacakan layanan publik, dan pelaporan masalah warga dalam satu aplikasi.*

> First Draft Submission, MIA 2026 (01 November 2026). This is a working front-end prototype. The backend is planned, not built yet.

## Tech stack
- **Front-end:** HTML, CSS, vanilla JavaScript (single page, no framework, no build step)
- **Offline / install:** Progressive Web App (service worker `sw.js` + `manifest.webmanifest`)
- **Storage (prototype):** browser `localStorage` for settings, notes and demo accounts
- **Dev server:** `http-server` (via npm) or Python's built-in server
- **Planned backend:** Node.js + Express, PostgreSQL (Supabase), OpenStreetMap/Leaflet. See [`docs/BACKEND_PLAN.txt`](docs/BACKEND_PLAN.txt)

## How to run
```bash
# 1. clone
git clone https://github.com/<your-username>/sambungwarga.git
cd sambungwarga

# 2. install
npm install

# 3. run
npm start
# open http://localhost:8080
```
No Node.js? Run `python3 -m http.server 8080` inside the folder and open http://localhost:8080.

Offline mode needs the app served over **HTTPS or localhost** (a plain double-clicked file will not register the service worker). To test: open the app once while online, then turn off your network and reload.

### Demo accounts
| Role | Username | Password |
|---|---|---|
| Registered user | `user` | `user1234` |
| Verified contributor | `contributor` | `contributor1234` |
| Moderator | `moderator` | `moderator1234` |
| Administrator | `admin` | `admin1234` |
| Super administrator | `superadmin` | `superadmin1234` |

You can also create your own account. New accounts are always Registered users. Only an administrator can grant the Administrator role.

## Current progress
Done (prototype):
- Three modes: **Emergency**, **Public Services**, **Civic Reports**, with responsive layouts (phone bottom tabs, tablet and desktop top tabs)
- Emergency Mode works **without sign-in** and **offline**: six categories with numbers, typical situations (including childbirth and obstetric emergencies) and safety tips in English and Bahasa Indonesia, nearby-help alarm, simulated ambulance request (clearly labeled), personal emergency contact, GPS coordinates
- Offline notes: notes written without internet are submitted automatically as reports for moderator review when the connection returns (demo: stored in this browser)
- Offline: only Emergency Mode and Settings are available; other modes explain that they need internet
- Civic reports with progress timelines, delay reasons, verification labels, moderation queue, and filters (all / submitted by me / community / resolved)
- Crime report type with private tips, rewards from victims or admins (always admin-approved, simulated points). Awarding points on an unresolved case shows a warning and needs a second confirmation, and the audit log records it
- Accounts with passwords, role-based screens, role grants by administrators, audit log
- Settings (gear icon in the top bar, available to guests): theme, accent color, text size, high contrast, reduce motion, language (English / Bahasa Indonesia), topics, emergency contact, notification preferences

Not done yet:
- Real backend, database and server-side authentication (accounts and roles are simulated in the browser)
- Live maps, real nearby-provider data, real photo upload, push/email notifications
- Full Bahasa Indonesia coverage (navigation, Home, Emergency and Settings only)
- Automated tests

## Simulated features and limits
- No real emergency dispatch, ambulance booking or payment happens. Requests and rewards are simulations with sample data.
- Emergency numbers must be verified against official Indonesian sources before release; availability varies by region. 112 is not connected in every region yet, and sources disagree on whether 129 is the disaster post or the violence-against-women-and-children line, so confirm it before release.
- Browser-side passwords are for the demo only and are not secure. Production needs server-side hashing and sessions (see backend plan).

## Project structure
```
index.html              the app (HTML, CSS, JS)
sw.js                   service worker (offline cache)
manifest.webmanifest    install metadata
icon-192.png, icon-512.png
docs/BACKEND_PLAN.txt   planned backend (plain text)
package.json            dev server script
```
